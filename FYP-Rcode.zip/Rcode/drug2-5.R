d=read.csv(file.choose(),header=F)

install.packages("npreg")
install.packages("stats")
library(npreg)
library(stats)
x_1T=c(400,80,16,4,0,400,80,16,4,0,0)
x_4T=c(400,80,16,0,3.2,400,80,16,0,3.2,0)
x_5N=c(400,80,16,0,3.2,400,80,16,0,3.2)
x_6T=c(400,80,16,0,3.2,400,80,16,3.2)
x_2T=c(400,80,16,0,200,400,80,16,0,200,80,0,200)
x_7T=c(16,0,320,160,64,16,0,320,160,64,16,0,320,160,64)
x_3T=c(80,16,0,3.2,320,80,16,0,3.2,320,80,16,3.2,320)
x_8T=c(80,16,0,3.2,320,80,16,0,3.2,320,0)
x_3N=c(80,16,4,0,320,80,16,4,0,320,80,16,4,0,320)
x_2N=c(80,16,4,0,320,80,16,4,0,320,80,16,4,0,320)
x_9T=c(80,16,3.2,320,80,16,3.2,320,80,16,3.2,320)
x_10N=c(16,4,0,320,16,4,0,320,16,4,0,320)

x_1T=log(x_1T+1)
x_4T=log(x_4T+1)
x_5N=log(x_5N+1)
x_6T=log(x_6T+1)
x_2T=log(x_2T+1)
x_7T=log(x_7T+1)
x_3T=log(x_3T+1)
x_8T=log(x_8T+1)
x_3N=log(x_3N+1)
x_2N=log(x_2N+1)
x_9T=log(x_9T+1)
x_10N=log(x_10N+1)

y_1T=unlist(d[2,2:31])
y_4T=unlist(d[3,2:31])
y_5N=unlist(d[4,2:31])
y_6T=unlist(d[5,2:31])
y_2T=unlist(d[6,2:31])
y_7T=unlist(d[7,2:31])
y_3T=unlist(d[8,2:31])
y_8T=unlist(d[9,2:31])
y_3N=unlist(d[10,2:31])
y_2N=unlist(d[11,2:31])
y_9T=unlist(d[12,2:31])
y_10N=unlist(d[13,2:31])
y_1T=na.omit(y_1T)
y_4T=na.omit(y_4T)
y_5N=na.omit(y_5N)
y_6T=na.omit(y_6T)
y_2T=na.omit(y_2T)
y_7T=na.omit(y_7T)
y_3T=na.omit(y_3T)
y_8T=na.omit(y_8T)
y_3N=na.omit(y_3N)
y_2N=na.omit(y_2N)
y_9T=na.omit(y_9T)
y_10N=na.omit(y_10N)
#1T
plot(x_1T,y_1T,pch=1,col="red",type="o")
mod.ss_1T=ss(x_1T,y_1T,m=1,method="GCV",nknots=4)
summary(mod.ss_1T)
plot(mod.ss_1T,col="red",xlab="log(concentration+1)",ylab="cell viability",main="DRUG1_1T",ylim=c(-0.1,1.25))
points(x_1T,y_1T,pch=1,col="red")
summary(mod.ss_1T)
#MAE_1T=apply(abs(mod.ss_1T$y-y_1T),1,mean)
#MSE_1T=apply((mod.ss_1T$y-y_1T)^2,1,mean)
#4T
plot(x_4T,y_4T,pch=2,col="blue",type="o")
mod.ss_4T=ss(x_4T,y_4T,m=1,method="GCV",nknots=3)
plot(mod.ss_4T,col="red",xlab="log(concentration+1)",ylab="cell viability",main="DRUG1_4T",ylim=c(-0.1,1.2))
points(x_4T,y_4T,pch=1,col="red")
summary(mod.ss_4T)
#MAE_4T=apply(abs(mod.ss_4T$y-y_4T),1,mean)
#MSE_4T=apply((mod.ss_4T$y-y_4T)^2,1,mean)
#5N
plot(x_5N,y_5N,pch=3,col="green",type="o")
mod.ss_5N=ss(x_5N,y_5N,m=1,method="GCV",nknots=2)
plot(mod.ss_5N,col="red",xlab="log(concentration+1)",ylab="cell viability",main="DRUG1_5N",ylim=c(-0.1,1.1))
points(x_5N,y_5N,pch=1,col="red")
summary(mod.ss_5N)
#MAE_5N=apply(abs(mod.ss_5N$y-y_5N),1,mean)
#MSE_5N=apply((mod.ss_5N$y-y_5N)^2,1,mean)
#6T
plot(x_6T,y_6T,pch=4,col="antiquewhite3",type="o")
mod.ss_6T=ss(x_6T,y_6T,m=1,method="GCV",nknots=4)#23
plot(mod.ss_6T,col="red",xlab="log(concentration+1)",ylab="cell viability",main="DRUG1_6T",ylim=c(-0.1,1.1))
points(x_6T,y_6T,pch=1,col="red")
summary(mod.ss_6T)
#MAE_6T=apply(abs(mod.ss_6T$y-y_6T),1,mean)
#MSE_6T=apply((mod.ss_6T$y-y_6T)^2,1,mean)
#2T
plot(x_2T,y_2T,pch=5,col="yellow",type="o")
mod.ss_2T=ss(x_2T,y_2T,m=1,method="GCV",nknots=3)
plot(mod.ss_2T,col="red",xlab="log(concentration+1)",ylab="cell viability",main="DRUG1_2T",ylim=c(-0.1,1.1))
points(x_2T,y_2T,pch=1,col="red")
summary(mod.ss_2T)
#MAE_2T=apply(abs(mod.ss_2T$y-y_2T),1,mean)
#MSE_2T=apply((mod.ss_2T$y-y_2T)^2,1,mean)
#7T
plot(x_7T,y_7T,pch=6,col="grey",type="o")
mod.ss_7T=ss(x_7T,y_7T,m=1,method="GCV",nknots=2)
plot(mod.ss_7T,col="red",xlab="log(concentration+1)",ylab="cell viability",main="DRUG1_7T",ylim=c(-0.1,1.1))
points(x_7T,y_7T,pch=1,col="red")
summary(mod.ss_7T)
#MAE_7T=apply(abs(mod.ss_7T$y-y_7T),1,mean)
#MSE_7T=apply((mod.ss_7T$y-y_7T)^2,1,mean)
#3T
plot(x_3T,y_3T,pch=7,col="pink",type="o")
mod.ss_3T=ss(x_3T,y_3T,m=1,method="GCV",nknots=3)#23
plot(mod.ss_3T,col="red",xlab="log(concentration+1)",ylab="cell viability",main="DRUG1_3T",ylim=c(-0.1,1.2))
points(x_3T,y_3T,pch=1,col="red")
summary(mod.ss_3T)#p_value
#MAE_3T=apply(abs(mod.ss_3T$y-y_3T),1,mean)
#MSE_3T=apply((mod.ss_3T$y-y_3T)^2,1,mean)
#8T
plot(x_8T,y_8T,pch=8,col="cyan",type="o")
mod.ss_8T=ss(x_8T,y_8T,m=1,method="GCV",nknots=4)#23
plot(mod.ss_8T,col="red",xlab="log(concentration+1)",ylab="cell viability",main="DRUG1_8T",ylim=c(-0.2,1.1))
points(x_8T,y_8T,pch=1,col="red")
summary(mod.ss_8T)
#MAE_8T=apply(abs(mod.ss_8T$y-y_8T),1,mean)
#MSE_8T=apply((mod.ss_8T$y-y_8T)^2,1,mean)
#3N
plot(x_3N,y_3N,pch=9,col="orange",type="o")
mod.ss_3N=ss(x_3N,y_3N,m=1,method="GCV",nknots=4)#23
plot(mod.ss_3N,col="red",xlab="log(concentration+1)",ylab="cell viability",main="DRUG1_3N",ylim=c(-0.1,1.1))
points(x_3N,y_3N,pch=1,col="red")
summary(mod.ss_3N)
#MAE_3N=apply(abs(mod.ss_3N$y-y_3N),1,mean)
#MSE_3N=apply((mod.ss_3N$y-y_3N)^2,1,mean)
#2N
plot(x_2N,y_2N,pch=10,col="purple",type="o")
mod.ss_2N=ss(x_2N,y_2N,m=1,method="GCV",nknots=4)#23
plot(mod.ss_2N,col="red",xlab="log(concentration+1)",ylab="cell viability",main="DRUG1_2N",ylim=c(-0.1,1.1))
points(x_2N,y_2N,pch=1,col="red")
summary(mod.ss_2N)
#MAE_2N=apply(abs(mod.ss_2N$y-y_2N),1,mean)
#MSE_2N=apply((mod.ss_2N$y-y_2N)^2,1,mean)
#9T
plot(x_9T,y_9T,pch=11,col="brown",type="o")
mod.ss_9T=ss(x_9T,y_9T,m=1,method="GCV",nknots=2)
plot(mod.ss_9T,col="red",xlab="log(concentration+1)",ylab="cell viability",main="DRUG1_9T",ylim=c(-0.1,1.1))
points(x_9T,y_9T,pch=1,col="red")
summary(mod.ss_9T)
#MAE_9T=apply(abs(mod.ss_9T$y-y_9T),1,mean)
#MSE_9T=apply((mod.ss_9T$y-y_9T)^2,1,mean)
#10N
plot(x_10N,y_10N,pch=12,col="black",type="o")
mod.ss_10N=ss(x_10N,y_10N,m=1,method="GCV",nknots=2)
plot(mod.ss_10N,,col="red",xlab="log(concentration+1)",ylab="cell viability",main="DRUG1_10T",ylim=c(-0.1,1.1))
points(x_10N,y_10N,pch=1,col="red")
summary(mod.ss_10N)
#MAE_10N=apply(abs(mod.ss_10N$y-y_10N),1,mean)
#MSE_10N=apply((mod.ss_10N$y-y_10N)^2,1,mean)
plot(1,xlab="log(concentration+1)",ylab="cell viability",main="Drug2_5",xlim=c(0,8),ylim=c(-0.1,1.25),type="n")
lines(mod.ss_1T,col=1,type="l",pch=1)
points(x_1T,y_1T,pch=1,col=1)

lines(mod.ss_4T,col=2,type="l",pch=2)
points(x_4T,y_4T,pch=2,col=2)

lines(mod.ss_5N,col=3,type="l",pch=3)
points(x_5N,y_5N,pch=3,col=3)

lines(mod.ss_6T,col=4,type="l",pch=4)
points(x_6T,y_6T,pch=4,col=4)

lines(mod.ss_2T,col=5,type="l",pch=5)
points(x_2T,y_2T,pch=5,col=5)

lines(mod.ss_7T,col=6,type="l",pch=6)
points(x_7T,y_7T,pch=6,col=6)

lines(mod.ss_3T,col=7,type="l",pch=7)
points(x_3T,y_3T,pch=7,col=7)

lines(mod.ss_8T,col=8,type="l",pch=8)
points(x_8T,y_8T,pch=8,col=8)

lines(mod.ss_3N,col=9,type="l",pch=9)
points(x_3N,y_3N,pch=9,col=9)

lines(mod.ss_2N,col=10,type="l",pch=10)
points(x_2N,y_2N,pch=10,col=10)

lines(mod.ss_9T,col=11,type="l",pch=11)
points(x_9T,y_9T,pch=11,col=11)

lines(mod.ss_10N,col=12,type="l",pch=12)
points(x_10N,y_10N,pch=12,col=12)
legend("topright",c("1T","4T","5N","6T","2T","7T"
                    ,"3T","8T","3N","2N","9T","10N"),col=1:12,pch=1:12,ncol=2,text.width = 0.6,cex=1)
##cluster
ww=read.csv(file.choose(),header=T)
attach(ww)
ww$x=log(ww$x+1)
r2 <- kregcurves(y = ww$y, x =ww$x,z=ww$z,k = 2, algorithm = "kmeans")
autoplot(r2,centers = TRUE)
r3 <- kregcurves(y = ww$y, x =ww$x,z=ww$z,k = 3, algorithm = "kmeans")
autoplot(r3,centers = TRUE)

x1=ww$x[1:5]

#5 and 8 cluster
x1=c(0,2,5,10,25,50,100,250)
x1=log(x1+1)
x=x1
p_1T=predict(mod.ss_1T,x1)[,2]
p_4T=predict(mod.ss_4T,x1)[,2]
p_5N=predict(mod.ss_5N,x1)[,2]
p_6T=predict(mod.ss_6T,x1)[,2]
p_2T=predict(mod.ss_2T,x1)[,2]
p_7T=predict(mod.ss_7T,x1)[,2]
p_3T=predict(mod.ss_3T,x1)[,2]
p_8T=predict(mod.ss_8T,x1)[,2]
p_3N=predict(mod.ss_3N,x1)[,2]
p_2N=predict(mod.ss_2N,x1)[,2]
p_9T=predict(mod.ss_9T,x1)[,2]
p_10N=predict(mod.ss_10N,x1)[,2]
p_11T=predict(mod.ss_11T,x)[,2]
p_12T=predict(mod.ss_12T,x)[,2]
p_13T=predict(mod.ss_13T,x)[,2]
p_14T=predict(mod.ss_14T,x)[,2]
p_12N=predict(mod.ss_12N,x)[,2]
p_14N=predict(mod.ss_14N,x)[,2]
p_15T=predict(mod.ss_15T,x)[,2]
p_16T=predict(mod.ss_16T,x)[,2]
y=c(p_1T,p_4T,p_5N,p_6T,p_2T,p_7T,p_3T,p_8T,p_3N,p_2N,p_9T,p_10N,p_11T,p_12T,p_13T,p_14T,p_12N,p_14N,p_15T,p_16T)
z=c(rep(1,8),rep(2,8),rep(3,8),rep(4,8),rep(5,8),rep(6,8),rep(7,8),rep(8,8),rep(9,8),rep(10,8),rep(11,8)
    ,rep(12,8),rep(13,8),rep(14,8),rep(15,8),rep(16,8),rep(17,8),rep(18,8),rep(19,8),rep(20,8))
x2=rep(x,20)
r2 <- kregcurves(y = y, x =x2,z=z,k = 2, algorithm = "kmeans")
autoplot(r2,centers = TRUE)
r3 <- kregcurves(y = y, x =x2,z=z,k = 3, algorithm = "kmeans")
autoplot(r3,centers = TRUE)
ds=rbind(p_1T,p_4T,p_5N,p_6T,p_2T,p_7T,p_3T,p_8T,p_3N,p_2N,p_9T,p_10N,p_11T,p_12T,p_13T,p_14T,p_12N,p_14N,p_15T,p_16T)
ds=as.matrix(ds)
hc1 <- hclust(dist(ds), method="average")
hc2 <- hclust(dist(ds), method="single")
hc3 <- hclust(dist(ds), method="complete")
plot(hc1,main="Cluster Dendrogram(average)",xlab="")
plot(hc2,main="Cluster Dendrogram(single)",xlab="")
plot(hc3,main="Cluster Dendrogram(complete)",xlab="")
cc<-rect.hclust(hc1,2,border='red')
cc2<-rect.hclust(hc1,3,border='red')
cc<-rect.hclust(hc2,2,border='red')
cc2<-rect.hclust(hc2,3,border='red')
cc<-rect.hclust(hc3,2,border='red')
cc2<-rect.hclust(hc3,3,border='red')
#predict
ww=read.csv(file.choose(),header=T)
attach(ww)
ww$x=log(ww$x+1)
x1=ww$x[1:5]
p_1T=predict(mod.ss_1T,x1)[,2]
p_4T=predict(mod.ss_4T,x1)[,2]
p_5N=predict(mod.ss_5N,x1)[,2]
p_6T=predict(mod.ss_6T,x1)[,2]
p_2T=predict(mod.ss_2T,x1)[,2]
p_7T=predict(mod.ss_7T,x1)[,2]
p_3T=predict(mod.ss_3T,x1)[,2]
p_8T=predict(mod.ss_8T,x1)[,2]
p_3N=predict(mod.ss_3N,x1)[,2]
p_2N=predict(mod.ss_2N,x1)[,2]
p_9T=predict(mod.ss_9T,x1)[,2]
p_10N=predict(mod.ss_10N,x1)[,2]
y=c(p_1T,p_4T,p_5N,p_6T,p_2T,p_7T,p_3T,p_8T,p_3N,p_2N,p_9T,p_10N)
z=c(rep(1,5),rep(2,5),rep(3,5),rep(4,5),rep(5,5),rep(6,5),rep(7,5),rep(8,5),rep(9,5),rep(10,5),rep(11,5)
    ,rep(12,5))
x2=rep(x1,12)
r2 <- kregcurves(y = y, x =x2,z=z,k = 2, algorithm = "kmeans")
autoplot(r2,centers = TRUE)
r3 <- kregcurves(y = y, x =x2,z=z,k = 3, algorithm = "kmeans")
autoplot(r3,centers = TRUE)
