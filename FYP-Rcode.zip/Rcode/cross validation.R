#0.13
xx=c(0,0,0,log(250),log(250),log(50),log(50),log(50),log(10),log(10),log(10),log(2),log(2))
yy=c(0.947764,1.014669,1.037567,0.878028,0.749367,0.968109,0.945664,0.945664,
     0.67867,0.819951,0.653131,0.954695,1.030644)
CV1=rep(0,3)
CV2=rep(0,3)
MSE1=rep(0,13)
MAE1=rep(0,13)
x=xx
y=yy
for(j in 1:3){
  for(i in 1:13){
    ind1=rep(1,13)
    ind1[i]=2
    data_train=x[ind1==1]
    data_val=x[ind1==2]
    mod.ss=ss(data_train,y[-i],m=1,method="GCV",nknots=j+1)
    p1=predict(mod.ss,data_val)
    MSE1[i]=sum((y[i]-p1[2])^2)/length(data_val)
    MAE1[i]=sum(abs(y[i]-p1[2]))/length(data_val)
  }
  
  CV1[j]=mean(MSE1)
  CV2[j]=mean(MAE1)
}
#5����
y=y_10N
CV1=rep(0,2)
CV2=rep(0,2)
MSE1=rep(0,3)
MAE1=rep(0,3)
x=x2
for(j in 1:2){
  for(i in 2:4){
    ind1=rep(1,5)
    ind1[i]=2
    data_train=x[ind1==1]
    data_val=x[ind1==2]
    mod.ss=ss(data_train,y[-i],m=1,method="GCV",nknots=j+1)
    p1=predict(mod.ss,data_val)
    MSE1[i-1]=sum((y[i]-p1[2])^2)/length(data_val)
    MAE1[i-1]=sum(abs(y[i]-p1[2]))/length(data_val)
  }
  
  CV1[j]=mean(MSE1)
  CV2[j]=mean(MAE1)
}
#8����
y=y_11T
y=y2_12T
y=y2_13T
y=y2_14T
y=y_12N
y=y2_14N
y=y2_15T
y=y2_16T
#data=dm[8,]
CV1=rep(0,5)
CV2=rep(0,5)
MSE1=rep(0,6)
MAE1=rep(0,6)

for(j in 1:5){
for(i in 2:7){
  ind1=rep(1,8)
  ind1[i]=2
  data_train=x[ind1==1]
  data_val=x[ind1==2]
  mod.ss=ss(data_train,y[-i],m=1,method="GCV",nknots=j+1)
  p1=predict(mod.ss,data_val)
  MSE1[i-1]=sum((y[i]-p1[2])^2)/length(data_val)
  MAE1[i-1]=sum(abs(y[i]-p1[2]))/length(data_val)
}
  
  CV1[j]=mean(MSE1)
  CV2[j]=mean(MAE1)
}

CV3=rep(0,4)
CV4=rep(0,4)
MSE1=rep(0,100)
MSE2=rep(0,100)
MAE1=rep(0,100)
MAE2=rep(0,100)
for(j in 1:4){
  for(i in 1:100){
    sam=sample(2:7,1)
    ind1=rep(1,8)
    ind1[sam]=2
    data_train=x[ind1==1]
    data_val=x[ind1==2]
    mod.ss=ss(data_train,y[-sam],m=2,method="GCV",nknots=j+2)
    p1=predict(mod.ss,data_val)
    MSE1[i]=sum((data[sam]-p1[2])^2)/length(data_val)
    MAE1[i]=sum(abs(data[sam]-p1[2]))/length(data_val)
  }
  na.omit(MSE1)
  na.omit(MAE1)
  CV3[j]=mean(MSE1)
  CV4[j]=mean(MAE1)
}


CV5=rep(0,4)
CV6=rep(0,4)
MSE1=rep(0,100)
MSE2=rep(0,100)
MAE1=rep(0,100)
MAE2=rep(0,100)
for(j in 1:4){
  for(i in 1:100){
    sam=sample(2:7,1)
    ind1=rep(1,8)
    ind1[sam]=2
    data_train=x[ind1==1]
    data_val=x[ind1==2]
    mod.ss=ss(data_train,y[-sam],m=3,method="GCV",nknots=j+2)
    p1=predict(mod.ss,data_val)
    MSE1[i]=sum((data[sam]-p1[2])^2)/length(data_val)
    MAE1[i]=sum(abs(data[sam]-p1[2]))/length(data_val)
  }
  na.omit(MSE1)
  na.omit(MAE1)
  CV5[j]=mean(MSE1)
  CV6[j]=mean(MAE1)
}
MSE=c(CV1,CV3,CV5)
MAE=c(CV2,CV4,CV6)

