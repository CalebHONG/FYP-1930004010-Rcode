d8=read.csv(file.choose(),header=T)
y_11T=d8[1,2:9]
y_12T=d8[2,2:9]
y_13T=d8[3,2:9]
y_14T=d8[4,2:9]
y_12N=d8[5,2:9]
y_14N=d8[6,2:9]
y_15T=d8[7,2:9]
y_16T=d8[8,2:9]
x=c(0,2,5,10,25,50,100,250)
x=log(x+1)
#11T
plot(x,y_11T,pch=1,col="red",type="o")
mod.ss_11T=ss(x,y_11T,m=1,method="GCV",nknots=6)#4
summary(mod.ss_11T)
plot(mod.ss_11T,col="red",xlab="log(concentration+1)",ylab="cell viability",main="DRUG1_11T",ylim=c(-0.1,1.1))
points(x,y_11T,pch=1,col="red")
#MAE_11T=apply(abs(mod.ss_11T$y-y_11T),1,mean)
#MSE_11T=apply((mod.ss_11T$y-y_11T)^2,1,mean)
#12T
plot(x,y_12T,pch=1,col="red",type="o")
mod.ss_12T=ss(x,y_12T,m=1,method="GCV",nknots=6)
summary(mod.ss_12T)
plot(mod.ss_12T,col="red",xlab="log(concentration+1)",ylab="cell viability",main="DRUG1_12T",ylim=c(-0.1,1.1))
points(x,y_12T,pch=1,col="red")
#MAE_12T=apply(abs(mod.ss_12T$y-y_12T),1,mean)
#MSE_12T=apply((mod.ss_12T$y-y_12T)^2,1,mean)
#13T
plot(x,y_13T,pch=1,col="red",type="o")
mod.ss_13T=ss(x,y_13T,m=1,method="GCV",nknots=6)
summary(mod.ss_13T)
plot(mod.ss_13T,col="red",xlab="log(concentration+1)",ylab="cell viability",main="DRUG1_13T",ylim=c(-0.1,1.1))

points(x,y_13T,pch=1,col="red")
#MAE_13T=apply(abs(mod.ss_13T$y-y_13T),1,mean)
#MSE_13T=apply((mod.ss_13T$y-y_13T)^2,1,mean)
#14T
plot(x,y_14T,pch=1,col="red",type="o")
mod.ss_14T=ss(x,y_14T,m=1,method="GCV",nknots=4)
summary(mod.ss_14T)
plot(mod.ss_14T,col="red",xlab="log(concentration+1)",ylab="cell viability",main="DRUG1_14T",ylim=c(-0.1,1.1))
points(x,y_14T,pch=1,col="red")
#MAE_14T=apply(abs(mod.ss_14T$y-y_14T),1,mean)
#MSE_14T=apply((mod.ss_14T$y-y_14T)^2,1,mean)
#12N
plot(x,y_12N,pch=1,col="red",type="o")
mod.ss_12N=ss(x,y_12N,m=1,method="GCV",nknots=4)
summary(mod.ss_12N)
plot(mod.ss_12N,col="red",xlab="log(concentration+1)",ylab="cell viability",main="DRUG1_12N",ylim=c(-0.1,1.1))
points(x,y_12N,pch=1,col="red")
MAE_12N=apply(abs(mod.ss_12N$y-y_12N),1,mean)
MSE_12N=apply((mod.ss_12N$y-y_12N)^2,1,mean)
#14N
plot(x,y_14N,pch=1,col="red",type="o")
mod.ss_14N=ss(x,y_14N,m=1,method="GCV",nknots=6)
summary(mod.ss_14N)
plot(mod.ss_14N,col="red",xlab="log(concentration+1)",ylab="cell viability",main="DRUG1_14N",ylim=c(-0.1,1.1))
points(x,y_14N,pch=1,col="red")
MAE_14N=apply(abs(mod.ss_14N$y-y_14N),1,mean)
MSE_14N=apply((mod.ss_14N$y-y_14N)^2,1,mean)
#15T
plot(x,y_15T,pch=1,col="red",type="o")
mod.ss_15T=ss(x,y_15T,m=1,method="GCV",nknots=6)
summary(mod.ss_15T)
plot(mod.ss_15T,col="red",xlab="log(concentration+1)",ylab="cell viability",main="DRUG1_15T",ylim=c(-0.1,1.1))
points(x,y_15T,pch=1,col="red")
MAE_15T=apply(abs(mod.ss_15T$y-y_15T),1,mean)
MSE_15T=apply((mod.ss_15T$y-y_15T)^2,1,mean)
#16T
plot(x,y_16T,pch=1,col="red",type="o")
mod.ss_16T=ss(x,y_16T,m=1,method="GCV",nknots=6)
summary(mod.ss_16T)
plot(mod.ss_16T,col="red",xlab="log(concentration+1)",ylab="cell viability",main="DRUG1_16T",ylim=c(-0.1,1.1))
points(x,y_16T,pch=1,col="red")
MAE_16T=apply(abs(mod.ss_16T$y-y_16T),1,mean)
MSE_16T=apply((mod.ss_16T$y-y_16T)^2,1,mean)
#plot
plot(mod.ss_11T,col=1,pch=1,xlim=c(0,6.8),ylim=c(-0.1,1.2),xlab="log(x+1)",ylab="y",main="")
points(x,mod.ss_11T$y,pch=1,col="red")

plot(1,xlab="log(concentration+1)",ylab="cell viability",main="Drug1_8",xlim=c(0,6.8),ylim=c(-0.1,1.2),type="n")
lines(mod.ss_11T,col=1,type="l",pch=1)
points(x,y_11T,pch=1,col=1)

lines(mod.ss_12T,col=2,type="l",pch=2)
points(x,y_12T,pch=2,col=2)

lines(mod.ss_13T,col=3,type="l",pch=3)
points(x,y_13T,pch=3,col=3)

lines(mod.ss_14T,col=4,type="l",pch=4)
points(x,y_14T,pch=4,col=4)

lines(mod.ss_12N,col=5,type="l",pch=5)
points(x,y_12N,pch=5,col=5)

lines(mod.ss_14N,col=6,type="l",pch=6)
points(x,y_14N,pch=6,col=6)

lines(mod.ss_15T,col=7,type="l",pch=7)
points(x,y_15T,pch=7,col=7)

lines(mod.ss_16T,col=8,type="l",pch=8)
points(x,y_16T,pch=8,col=8)

legend("topright",c("11T","12T","13T","14T","12N","14N"
                 ,"15T","16T"),col=1:8,pch=1:8)
#classify_kmeans
x1=matrix(rep(x,8),ncol=1)
dm=as.matrix(d8[1:8,2:9])
dm1=t(dm)
y1=matrix(dm1)
z1=c(rep(1,8),rep(2,8),rep(3,8),rep(4,8),rep(5,8),rep(6,8),rep(7,8),rep(8,8))
data=cbind(x1,y1,z1)
colnames(data) <- c("x", "y","z")
plot(data)
#cl<-kmeans(data, 3)
#cl$withinss
#cl$cluster
#plot(data, col = cl$cluster)
#points(cl$centers, col = 1:3, pch = 8, cex=2)
#clustcurv
install.packages("clustcurv")
library(clustcurv)
r2 <- kregcurves(y = y1, x =x1,z=z1,k = 2, algorithm = "kmeans")
autoplot(r2,centers = TRUE)
r3 <- kregcurves(y = y1, x =x1,z=z1,k = 3, algorithm = "kmeans")
autoplot(r3,centers = TRUE)
#h cluster
hc1 <- hclust(dist(dm), method="average")
hc2 <- hclust(dist(dm), method="single")
hc3<- hclust(dist(dm), method="complete")
plot(hc1,main="Cluster Dendrogram(average)",xlab="")
plot(hc2,main="Cluster Dendrogram(single)",xlab="")
plot(hc3,main="Cluster Dendrogram(complete)",xlab="")
cc<-rect.hclust(hc1,2,border='red')
cc2<-rect.hclust(hc1,3,border='red')
cc<-rect.hclust(hc2,2,border='red')
cc2<-rect.hclust(hc2,3,border='red')
cc<-rect.hclust(hc3,2,border='red')
cc2<-rect.hclust(hc3,3,border='red')
#������ݼ�
p_11T=predict(mod.ss_11T,x)[,2]
p_12T=predict(mod.ss_12T,x)[,2]
p_13T=predict(mod.ss_13T,x)[,2]
p_14T=predict(mod.ss_14T,x)[,2]
p_12N=predict(mod.ss_12N,x)[,2]
p_14N=predict(mod.ss_14N,x)[,2]
p_15T=predict(mod.ss_15T,x)[,2]
p_16T=predict(mod.ss_16T,x)[,2]
p=c(p_11T,p_12T,p_13T,p_14T,p_12N,p_14N,p_15T,p_16T)
x2=rep(predict(mod.ss_11T,x)[,1],8)
z2=c(rep(1,8),rep(2,8),rep(3,8),rep(4,8),rep(5,8),rep(6,8),rep(7,8),rep(8,8))
r2 <- kregcurves(y = p, x =x2,z=z2,k = 2, algorithm = "kmeans")
autoplot(r2,groups_by_colour = TRUE, centers = TRUE,xlab="log(x+1)",ylab=y)
r3 <- kregcurves(y = p, x =x2,z=z2,k = 3, algorithm = "kmeans")
autoplot(r3,groups_by_colour = TRUE, centers = TRUE)
#h cluster
ds=rbind(p_11T,p_12T,p_13T,p_14T,p_12N,p_14N,p_15T,p_16T)
ds=as.matrix(ds)
hc1 <- hclust(dist(ds), method="average")
hc2 <- hclust(dist(ds), method="single")
hc3 <- hclust(dist(ds), method="complete")
plot(hc1,main="Cluster Dendrogram(average)",xlab="")
plot(hc2,main="Cluster Dendrogram(single)",xlab="")
plot(hc3,main="Cluster Dendrogram(complete)",xlab="")
cc<-rect.hclust(hc1,2,border='red')
cc2<-rect.hclust(hc1,3,border='red')
cc<-rect.hclust(hc2,2,border='red')
cc2<-rect.hclust(hc2,3,border='red')
cc<-rect.hclust(hc3,2,border='red')
cc2<-rect.hclust(hc3,3,border='red')
#separate k=2
w1=seq(0, 5.6, length=100)
q_11T=predict(mod.ss_11T,w1)[,2]
q_12T=predict(mod.ss_12T,w1)[,2]
q_13T=predict(mod.ss_13T,w1)[,2]
q_14T=predict(mod.ss_14T,w1)[,2]
q_12N=predict(mod.ss_12N,w1)[,2]
q_14N=predict(mod.ss_14N,w1)[,2]
q_15T=predict(mod.ss_15T,w1)[,2]
q_16T=predict(mod.ss_16T,w1)[,2]
diff=((q_12N+q_14N)/2)-((q_11T+q_12T+q_13T+q_14T+q_15T+q_16T)/6)

which(diff==max(diff))
w1[582]

#separate k=3
diff=(((q_13T+q_14T+q_16T)/3)-((q_11T+q_12T+q_15T)/3))
plot(w1,(q_13T+q_14T+q_16T)/3,ylim=c(-0.1,1),main="Simulating points on the center line",xlab="log(concentration+1)",ylab="cell viability")
points(w1,(q_11T+q_12T+q_15T)/3)
which(diff==max(diff))
w1[59]
abline(v=3.28,col ="red",lwd=3)
text(3.28,0.5,expression(x==3.28),c(-0.3,0.9),col="red",cex=1.2)
#Silhouette Coefficient
p_11T=predict(mod.ss_11T,x)[,2]
p_12T=predict(mod.ss_12T,x)[,2]
p_13T=predict(mod.ss_13T,x)[,2]
p_14T=predict(mod.ss_14T,x)[,2]
p_12N=predict(mod.ss_12N,x)[,2]
p_14N=predict(mod.ss_14N,x)[,2]
p_15T=predict(mod.ss_15T,x)[,2]
p_16T=predict(mod.ss_16T,x)[,2]
R11=(p_12N+p_14N)/2
R12=(p_11T+p_12T+p_15T)/3
R13=(p_13T+p_14T+p_16T)/3
#11T, 12T, 15T \quad Group2:  13T, 14T, 16T
#11T
a1=(abs(p_11T-p_12T)+abs(p_11T-p_15T))/2
b1=(abs(p_11T-p_13T)+abs(p_11T-p_14T)+abs(p_11T-p_16T))/3
c1=rbind(a1,b1)
d1=apply(c1,2,max)
s1=mean((b1-a1)/d1)
#12T
a2=(abs(p_12T-p_11T)+abs(p_12T-p_15T))/2
b2=(abs(p_12T-p_13T)+abs(p_12T-p_14T)+abs(p_12T-p_16T))/3
c2=rbind(a2,b2)
d2=apply(c2,2,max)
s2=mean((b2-a2)/d2)
#15T
a5=(abs(p_15T-p_11T)+abs(p_15T-p_12T))/2
b5=(abs(p_15T-p_13T)+abs(p_15T-p_14T)+abs(p_15T-p_16T))/3
c5=rbind(a5,b5)
d5=apply(c5,2,max)
s5=mean((b5-a5)/d5)
#13T
a3=(abs(p_13T-p_14T)+abs(p_13T-p_16T))/2
b3=(abs(p_13T-p_11T)+abs(p_13T-p_12T)+abs(p_13T-p_15T))/3
c3=rbind(a3,b3)
d3=apply(c3,2,max)
s3=mean((b3-a3)/d3)
#14T
a4=(abs(p_14T-p_13T)+abs(p_14T-p_16T))/2
b4=(abs(p_14T-p_11T)+abs(p_14T-p_12T)+abs(p_14T-p_15T))/3
c4=rbind(a4,b4)
d4=apply(c4,2,max)
s4=mean((b4-a4)/d4)
#16T
a6=(abs(p_16T-p_13T)+abs(p_16T-p_14T))/2
b6=(abs(p_16T-p_11T)+abs(p_16T-p_12T)+abs(p_16T-p_15T))/3
c6=rbind(a6,b6)
d6=apply(c6,2,max)
s6=mean((b6-a6)/d6)
SC1=mean(c(s1,s2,s3,s4,s5,s6))
#Group1: 12T\quad Group2: 11T, 13T, 14T,  15T ,16T\\
#12T
#11T
a1=(abs(p_11T-p_13T)+abs(p_11T-p_14T)+abs(p_11T-p_15T)+abs(p_11T-p_16T))/4
b1=abs(p_11T-p_12T)
c1=rbind(a1,b1)
d1=apply(c1,2,max)
s1=mean((b1-a1)/d1)
#13T
a3=(abs(p_13T-p_11T)+abs(p_13T-p_14T)+abs(p_13T-p_15T)+abs(p_13T-p_16T))/4
b3=abs(p_13T-p_12T)
c3=rbind(a3,b3)
d3=apply(c3,2,max)
s3=mean((b3-a3)/d3)
#14T
a4=(abs(p_14T-p_11T)+abs(p_14T-p_13T)+abs(p_14T-p_15T)+abs(p_14T-p_16T))/4
b4=abs(p_14T-p_12T)
c4=rbind(a4,b4)
d4=apply(c4,2,max)
s4=mean((b4-a4)/d4)
#15T
a5=(abs(p_15T-p_11T)+abs(p_15T-p_13T)+abs(p_15T-p_14T)+abs(p_15T-p_16T))/4
b5=abs(p_15T-p_12T)
c5=rbind(a5,b5)
d5=apply(c5,2,max)
s5=mean((b5-a5)/d5)
#16T
a6=(abs(p_16T-p_11T)+abs(p_16T-p_13T)+abs(p_16T-p_14T)+abs(p_16T-p_15T))/4
b6=abs(p_16T-p_12T)
c6=rbind(a6,b6)
d6=apply(c6,2,max)
s6=mean((b6-a6)/d6)
SC2=mean(c(s1,s3,s4,s5,s6))
